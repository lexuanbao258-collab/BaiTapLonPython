-- =========================
-- 1. KIEU DU LIEU ENUM
-- =========================
CREATE TYPE vai_tro_nguoi_dung AS ENUM ('quan_tri', 'thu_thu');

CREATE TYPE trang_thai_phieu_muon AS ENUM ('dang_muon', 'da_tra', 'qua_han', 'da_huy');

CREATE TYPE trang_thai_thanh_toan AS ENUM ('chua_thanh_toan', 'da_thanh_toan');

CREATE TYPE ly_do_phat AS ENUM ('tra_tre', 'lam_hong', 'lam_mat');

-- =========================
-- 2. CAC BANG DANH MUC / HE THONG
-- =========================
CREATE TABLE nguoi_dung (
    id                  BIGSERIAL PRIMARY KEY,
    ten_dang_nhap       VARCHAR(50) NOT NULL UNIQUE,
    mat_khau_ma_hoa     TEXT NOT NULL,
    ho_ten              VARCHAR(150) NOT NULL,
    vai_tro             vai_tro_nguoi_dung NOT NULL,
    dang_hoat_dong      BOOLEAN NOT NULL DEFAULT TRUE,
    ngay_tao            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE nguoi_muon (
    id                  BIGSERIAL PRIMARY KEY,
    ma_nguoi_muon       VARCHAR(20) NOT NULL UNIQUE,
    ho_ten              VARCHAR(150) NOT NULL,
    so_dien_thoai       VARCHAR(20),
    email               VARCHAR(150),
    dia_chi             TEXT,
    ngay_tao            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE the_loai (
    id                  BIGSERIAL PRIMARY KEY,
    ten_the_loai        VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE nha_xuat_ban (
    id                  BIGSERIAL PRIMARY KEY,
    ten_nha_xuat_ban    VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE sach (
    id                  BIGSERIAL PRIMARY KEY,
    ma_sach             VARCHAR(20) NOT NULL UNIQUE,
    ten_sach            VARCHAR(255) NOT NULL,
    tac_gia             VARCHAR(150) NOT NULL,
    the_loai_id         BIGINT REFERENCES the_loai(id) ON DELETE SET NULL,
    nha_xuat_ban_id     BIGINT REFERENCES nha_xuat_ban(id) ON DELETE SET NULL,
    nam_xuat_ban        INT,
    vi_tri_ke           VARCHAR(50),
    tong_so_luong       INT NOT NULL DEFAULT 0 CHECK (tong_so_luong >= 0),
    so_luong_con        INT NOT NULL DEFAULT 0 CHECK (so_luong_con >= 0),
    dang_hoat_dong      BOOLEAN NOT NULL DEFAULT TRUE,
    ngay_tao            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_so_luong_sach
        CHECK (so_luong_con <= tong_so_luong),
    CONSTRAINT chk_nam_xuat_ban
        CHECK (
            nam_xuat_ban IS NULL
            OR (nam_xuat_ban >= 0 AND nam_xuat_ban <= EXTRACT(YEAR FROM CURRENT_DATE))
        )
);

-- =========================
-- 3. PHIEU MUON
-- =========================
CREATE TABLE phieu_muon (
    id                  BIGSERIAL PRIMARY KEY,
    ma_phieu_muon       VARCHAR(20) NOT NULL UNIQUE,
    nguoi_muon_id       BIGINT NOT NULL REFERENCES nguoi_muon(id) ON DELETE RESTRICT,
    nguoi_lap_id        BIGINT NOT NULL REFERENCES nguoi_dung(id) ON DELETE RESTRICT,
    ngay_muon           DATE NOT NULL DEFAULT CURRENT_DATE,
    ngay_hen_tra        DATE NOT NULL,
    trang_thai          trang_thai_phieu_muon NOT NULL DEFAULT 'dang_muon',
    ghi_chu             TEXT,
    ngay_tao            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_ngay_hen_tra
        CHECK (ngay_hen_tra >= ngay_muon)
);

CREATE TABLE chi_tiet_phieu_muon (
    id                  BIGSERIAL PRIMARY KEY,
    phieu_muon_id       BIGINT NOT NULL REFERENCES phieu_muon(id) ON DELETE CASCADE,
    sach_id             BIGINT NOT NULL REFERENCES sach(id) ON DELETE RESTRICT,
    so_luong            INT NOT NULL CHECK (so_luong > 0),
    UNIQUE (phieu_muon_id, sach_id)
);

-- =========================
-- 4. PHIEU TRA
-- =========================
CREATE TABLE phieu_tra (
    id                  BIGSERIAL PRIMARY KEY,
    ma_phieu_tra        VARCHAR(20) NOT NULL UNIQUE,
    phieu_muon_id       BIGINT NOT NULL UNIQUE REFERENCES phieu_muon(id) ON DELETE RESTRICT,
    nguoi_xu_ly_id      BIGINT NOT NULL REFERENCES nguoi_dung(id) ON DELETE RESTRICT,
    ngay_tra            DATE NOT NULL DEFAULT CURRENT_DATE,
    so_ngay_tre         INT NOT NULL DEFAULT 0 CHECK (so_ngay_tre >= 0),
    ghi_chu             TEXT,
    ngay_tao            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chi_tiet_phieu_tra (
    id                          BIGSERIAL PRIMARY KEY,
    phieu_tra_id                BIGINT NOT NULL REFERENCES phieu_tra(id) ON DELETE CASCADE,
    chi_tiet_phieu_muon_id      BIGINT NOT NULL REFERENCES chi_tiet_phieu_muon(id) ON DELETE RESTRICT,
    so_luong_tra                INT NOT NULL DEFAULT 0 CHECK (so_luong_tra >= 0),
    so_luong_hong               INT NOT NULL DEFAULT 0 CHECK (so_luong_hong >= 0),
    so_luong_mat                INT NOT NULL DEFAULT 0 CHECK (so_luong_mat >= 0),
    ghi_chu_tinh_trang          TEXT,
    CONSTRAINT chk_so_luong_tra_hong_mat
        CHECK (so_luong_tra + so_luong_hong + so_luong_mat > 0),
    UNIQUE (phieu_tra_id, chi_tiet_phieu_muon_id)
);

-- =========================
-- 5. PHIEU PHAT
-- =========================
CREATE TABLE phieu_phat (
    id                      BIGSERIAL PRIMARY KEY,
    ma_phieu_phat           VARCHAR(20) NOT NULL UNIQUE,
    nguoi_muon_id           BIGINT NOT NULL REFERENCES nguoi_muon(id) ON DELETE RESTRICT,
    phieu_muon_id           BIGINT NOT NULL REFERENCES phieu_muon(id) ON DELETE RESTRICT,
    phieu_tra_id            BIGINT REFERENCES phieu_tra(id) ON DELETE SET NULL,
    tong_tien               NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (tong_tien >= 0),
    trang_thai_thanh_toan   trang_thai_thanh_toan NOT NULL DEFAULT 'chua_thanh_toan',
    nguoi_lap_id            BIGINT NOT NULL REFERENCES nguoi_dung(id) ON DELETE RESTRICT,
    ngay_tao                TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ngay_thanh_toan         TIMESTAMP NULL
);

CREATE TABLE chi_tiet_phieu_phat (
    id                  BIGSERIAL PRIMARY KEY,
    phieu_phat_id       BIGINT NOT NULL REFERENCES phieu_phat(id) ON DELETE CASCADE,
    sach_id             BIGINT REFERENCES sach(id) ON DELETE SET NULL,
    ly_do               ly_do_phat NOT NULL,
    so_luong            INT NOT NULL DEFAULT 1 CHECK (so_luong > 0),
    don_gia_phat        NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (don_gia_phat >= 0),
    thanh_tien          NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (thanh_tien >= 0),
    ghi_chu             TEXT
);