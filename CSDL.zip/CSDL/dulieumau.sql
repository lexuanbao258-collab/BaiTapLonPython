BEGIN;

-- =========================================
-- 1. NGUOI DUNG
-- =========================================
INSERT INTO nguoi_dung (id, ten_dang_nhap, mat_khau_ma_hoa, ho_ten, vai_tro, dang_hoat_dong, ngay_tao)
VALUES
    (1, 'admin', 'admin123', 'Quản Trị Hệ Thống', 'quan_tri', TRUE, '2026-01-01 08:00:00'),
    (2, 'thuthu01', 'thuthu123', 'Nguyễn Thị Lan', 'thu_thu', TRUE, '2026-01-01 08:30:00'),
    (3, 'thuthu02', 'thuthu123', 'Trần Văn Minh', 'thu_thu', TRUE, '2026-01-02 09:00:00');

-- =========================================
-- 2. NGUOI MUON
-- =========================================
INSERT INTO nguoi_muon (id, ma_nguoi_muon, ho_ten, so_dien_thoai, email, dia_chi, ngay_tao)
VALUES
    (1, 'NM001', 'Lê Văn An', '0901000001', 'an@gmail.com', 'Đà Nẵng', '2026-01-05 08:00:00'),
    (2, 'NM002', 'Phạm Thị Bình', '0901000002', 'binh@gmail.com', 'Huế', '2026-01-05 08:10:00'),
    (3, 'NM003', 'Nguyễn Văn Cường', '0901000003', 'cuong@gmail.com', 'Quảng Nam', '2026-01-05 08:20:00'),
    (4, 'NM004', 'Trần Thị Dung', '0901000004', 'dung@gmail.com', 'Đà Nẵng', '2026-01-05 08:30:00');

-- =========================================
-- 3. THE LOAI
-- =========================================
INSERT INTO the_loai (id, ten_the_loai)
VALUES
    (1, 'Công nghệ thông tin'),
    (2, 'Văn học'),
    (3, 'Khoa học'),
    (4, 'Kinh tế'),
    (5, 'Thiếu nhi');

-- =========================================
-- 4. NHA XUAT BAN
-- =========================================
INSERT INTO nha_xuat_ban (id, ten_nha_xuat_ban)
VALUES
    (1, 'Nhà xuất bản Giáo Dục'),
    (2, 'Nhà xuất bản Trẻ'),
    (3, 'Nhà xuất bản Kim Đồng'),
    (4, 'Nhà xuất bản Lao Động');

-- =========================================
-- 5. SACH
-- =========================================
INSERT INTO sach (
    id, ma_sach, ten_sach, tac_gia, the_loai_id, nha_xuat_ban_id,
    nam_xuat_ban, vi_tri_ke, tong_so_luong, so_luong_con,
    dang_hoat_dong, ngay_tao, ngay_cap_nhat
)
VALUES
    (1, 'S001', 'Lập trình Python cơ bản', 'Nguyễn Văn A', 1, 1, 2022, 'A1', 10, 10, TRUE, '2026-01-10 08:00:00', '2026-01-10 08:00:00'),
    (2, 'S002', 'Cơ sở dữ liệu', 'Trần Văn B', 1, 1, 2021, 'A2', 7, 7, TRUE, '2026-01-10 08:05:00', '2026-01-10 08:05:00'),
    (3, 'S003', 'Tắt đèn', 'Ngô Tất Tố', 2, 2, 2019, 'B1', 6, 6, TRUE, '2026-01-10 08:10:00', '2026-01-10 08:10:00'),
    (4, 'S004', 'Vật lý đại cương', 'Lê Văn C', 3, 1, 2020, 'C1', 4, 4, TRUE, '2026-01-10 08:15:00', '2026-01-10 08:15:00'),
    (5, 'S005', 'Kinh tế vi mô', 'Phạm Văn D', 4, 4, 2023, 'D1', 5, 5, TRUE, '2026-01-10 08:20:00', '2026-01-10 08:20:00'),
    (6, 'S006', 'Dế mèn phiêu lưu ký', 'Tô Hoài', 5, 3, 2018, 'E1', 3, 3, TRUE, '2026-01-10 08:25:00', '2026-01-10 08:25:00'),
    (7, 'S007', 'Toán rời rạc', 'Nguyễn Văn E', 1, 1, 2024, 'A3', 8, 8, TRUE, '2026-01-10 08:30:00', '2026-01-10 08:30:00'),
    (8, 'S008', 'Kỹ năng giao tiếp', 'Hoàng Thị F', 4, 2, 2022, 'D2', 5, 5, TRUE, '2026-01-10 08:35:00', '2026-01-10 08:35:00');

-- =========================================
-- 6. PHIEU MUON
-- =========================================
INSERT INTO phieu_muon (
    id, ma_phieu_muon, nguoi_muon_id, nguoi_lap_id,
    ngay_muon, ngay_hen_tra, trang_thai, ghi_chu, ngay_tao
)
VALUES
    (1, 'PM001', 1, 2, '2026-02-20', '2026-02-27', 'da_tra', 'Mượn 2 sách', '2026-02-20 09:00:00'),
    (2, 'PM002', 2, 2, '2026-02-25', '2026-03-03', 'da_tra', 'Mượn 1 sách', '2026-02-25 10:00:00'),
    (3, 'PM003', 3, 3, '2026-03-01', '2026-03-08', 'dang_muon', 'Đang mượn 2 sách', '2026-03-01 08:30:00'),
    (4, 'PM004', 4, 3, '2026-02-18', '2026-02-25', 'da_tra', 'Mượn sách thiếu nhi', '2026-02-18 14:00:00');

-- =========================================
-- 7. CHI TIET PHIEU MUON
-- =========================================
INSERT INTO chi_tiet_phieu_muon (id, phieu_muon_id, sach_id, so_luong)
VALUES
    (1, 1, 1, 1),
    (2, 1, 3, 1),
    (3, 2, 2, 1),
    (4, 3, 4, 1),
    (5, 3, 5, 1),
    (6, 4, 6, 1);

-- =========================================
-- 8. PHIEU TRA
-- =========================================
INSERT INTO phieu_tra (
    id, ma_phieu_tra, phieu_muon_id, nguoi_xu_ly_id,
    ngay_tra, ghi_chu, ngay_tao
)
VALUES
    (1, 'PT001', 1, 2, '2026-03-01', 'Trả trễ 2 ngày, 1 sách bị hỏng', '2026-03-01 16:00:00'),
    (2, 'PT002', 2, 2, '2026-03-02', 'Trả đúng hạn', '2026-03-02 10:00:00'),
    (3, 'PT003', 4, 3, '2026-02-24', 'Làm mất sách', '2026-02-24 15:00:00');

-- =========================================
-- 9. CHI TIET PHIEU TRA
-- =========================================
INSERT INTO chi_tiet_phieu_tra (
    id, phieu_tra_id, chi_tiet_phieu_muon_id,
    so_luong_tra, so_luong_hong, so_luong_mat, ghi_chu_tinh_trang
)
VALUES
    (1, 1, 1, 1, 0, 0, 'Sách còn tốt'),
    (2, 1, 2, 0, 1, 0, 'Sách bị rách bìa'),
    (3, 2, 3, 1, 0, 0, 'Sách bình thường'),
    (4, 3, 6, 0, 0, 1, 'Người mượn báo mất sách');

-- =========================================
-- 10. CAP NHAT LAI SO_LUONG_CON SAU KHI TRA
-- =========================================
UPDATE sach SET so_luong_con = so_luong_con + 1 WHERE id = 1;
UPDATE sach SET so_luong_con = so_luong_con + 1 WHERE id = 2;

-- =========================================
-- 11. PHIEU PHAT
-- =========================================
INSERT INTO phieu_phat (
    id, ma_phieu_phat, nguoi_muon_id, phieu_muon_id, phieu_tra_id,
    tong_tien, trang_thai_thanh_toan, nguoi_lap_id, ngay_tao, ngay_thanh_toan
)
VALUES
    (1, 'PP001', 1, 1, 1, 55000, 'chua_thanh_toan', 2, '2026-03-01 16:30:00', NULL),
    (2, 'PP002', 4, 4, 3, 80000, 'da_thanh_toan', 3, '2026-02-24 15:30:00', '2026-02-24 16:00:00');

-- =========================================
-- 12. CHI TIET PHIEU PHAT
-- =========================================
INSERT INTO chi_tiet_phieu_phat (
    id, phieu_phat_id, sach_id, ly_do, so_luong, don_gia_phat, thanh_tien, ghi_chu
)
VALUES
    (1, 1, 1, 'tra_tre', 2, 5000, 10000, 'Trễ 2 ngày, 5000 mỗi ngày'),
    (2, 1, 3, 'lam_hong', 1, 45000, 45000, 'Sách bị hỏng cần đền bù'),
    (3, 2, 6, 'lam_mat', 1, 80000, 80000, 'Mất sách phải bồi thường');

COMMIT;




--select
SELECT setval(pg_get_serial_sequence('nguoi_dung', 'id'), COALESCE(MAX(id), 1), true) FROM nguoi_dung;
SELECT setval(pg_get_serial_sequence('nguoi_muon', 'id'), COALESCE(MAX(id), 1), true) FROM nguoi_muon;
SELECT setval(pg_get_serial_sequence('the_loai', 'id'), COALESCE(MAX(id), 1), true) FROM the_loai;
SELECT setval(pg_get_serial_sequence('nha_xuat_ban', 'id'), COALESCE(MAX(id), 1), true) FROM nha_xuat_ban;
SELECT setval(pg_get_serial_sequence('sach', 'id'), COALESCE(MAX(id), 1), true) FROM sach;
SELECT setval(pg_get_serial_sequence('phieu_muon', 'id'), COALESCE(MAX(id), 1), true) FROM phieu_muon;
SELECT setval(pg_get_serial_sequence('chi_tiet_phieu_muon', 'id'), COALESCE(MAX(id), 1), true) FROM chi_tiet_phieu_muon;
SELECT setval(pg_get_serial_sequence('phieu_tra', 'id'), COALESCE(MAX(id), 1), true) FROM phieu_tra;
SELECT setval(pg_get_serial_sequence('chi_tiet_phieu_tra', 'id'), COALESCE(MAX(id), 1), true) FROM chi_tiet_phieu_tra;
SELECT setval(pg_get_serial_sequence('phieu_phat', 'id'), COALESCE(MAX(id), 1), true) FROM phieu_phat;
SELECT setval(pg_get_serial_sequence('chi_tiet_phieu_phat', 'id'), COALESCE(MAX(id), 1), true) FROM chi_tiet_phieu_phat;


SELECT * FROM nguoi_dung;
SELECT * FROM nguoi_muon;
SELECT * FROM sach;
SELECT * FROM phieu_muon;
SELECT * FROM chi_tiet_phieu_muon;
SELECT * FROM phieu_tra;
SELECT * FROM chi_tiet_phieu_tra;
SELECT * FROM phieu_phat;
SELECT * FROM chi_tiet_phieu_phat;




