-- Tự cập nhật ngay_cap_nhat cho bảng sach
CREATE OR REPLACE FUNCTION cap_nhat_ngay_sua()
RETURNS TRIGGER AS $$
BEGIN
    NEW.ngay_cap_nhat = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sach_cap_nhat_ngay_sua
BEFORE UPDATE ON sach
FOR EACH ROW
EXECUTE FUNCTION cap_nhat_ngay_sua();


-- Tính so_ngay_tre khi trả sách
CREATE OR REPLACE FUNCTION tinh_so_ngay_tre()
RETURNS TRIGGER AS $$
DECLARE
    v_ngay_hen_tra DATE;
BEGIN
    SELECT ngay_hen_tra INTO v_ngay_hen_tra
    FROM phieu_muon
    WHERE id = NEW.phieu_muon_id;

    IF NEW.ngay_tra > v_ngay_hen_tra THEN
        NEW.so_ngay_tre = NEW.ngay_tra - v_ngay_hen_tra;
    ELSE
        NEW.so_ngay_tre = 0;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tinh_so_ngay_tre
BEFORE INSERT OR UPDATE ON phieu_tra
FOR EACH ROW
EXECUTE FUNCTION tinh_so_ngay_tre();


-- Kiểm tra tồn kho trước khi mượn
CREATE OR REPLACE FUNCTION kiem_tra_so_luong_sach_truoc_khi_muon()
RETURNS TRIGGER AS $$
DECLARE
    v_so_luong_con INT;
BEGIN
    SELECT so_luong_con INTO v_so_luong_con
    FROM sach
    WHERE id = NEW.sach_id;

    IF v_so_luong_con < NEW.so_luong THEN
        RAISE EXCEPTION 'Khong du so luong sach de muon';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_kiem_tra_so_luong_sach_truoc_khi_muon
BEFORE INSERT ON chi_tiet_phieu_muon
FOR EACH ROW
EXECUTE FUNCTION kiem_tra_so_luong_sach_truoc_khi_muon();



-- Trừ số lượng còn sau khi mượn
CREATE OR REPLACE FUNCTION tru_so_luong_sach_sau_khi_muon()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE sach
    SET so_luong_con = so_luong_con - NEW.so_luong
    WHERE id = NEW.sach_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tru_so_luong_sach_sau_khi_muon
AFTER INSERT ON chi_tiet_phieu_muon
FOR EACH ROW
EXECUTE FUNCTION tru_so_luong_sach_sau_khi_muon();