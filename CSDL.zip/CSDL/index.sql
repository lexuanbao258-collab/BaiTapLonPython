CREATE INDEX idx_sach_ten_sach ON sach (LOWER(ten_sach));
CREATE INDEX idx_sach_tac_gia ON sach (LOWER(tac_gia));
CREATE INDEX idx_sach_the_loai_id ON sach (the_loai_id);

CREATE INDEX idx_nguoi_muon_ho_ten ON nguoi_muon (LOWER(ho_ten));
CREATE INDEX idx_nguoi_muon_so_dien_thoai ON nguoi_muon (so_dien_thoai);

CREATE INDEX idx_phieu_muon_nguoi_muon_id ON phieu_muon (nguoi_muon_id);
CREATE INDEX idx_phieu_muon_trang_thai ON phieu_muon (trang_thai);
CREATE INDEX idx_phieu_muon_ngay_hen_tra ON phieu_muon (ngay_hen_tra);

CREATE INDEX idx_chi_tiet_phieu_muon_sach_id ON chi_tiet_phieu_muon (sach_id);

CREATE INDEX idx_phieu_tra_phieu_muon_id ON phieu_tra (phieu_muon_id);
CREATE INDEX idx_phieu_phat_trang_thai_thanh_toan ON phieu_phat (trang_thai_thanh_toan);